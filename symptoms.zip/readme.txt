
1. Place the coding in below path 
c:\xampp\htdocs\projects\symptoms\web

2. Opent  localhost/phpmyadmin
   Crete DB - health_sympton
   
3. Import health_sympton.sql 

4. For Project run the path in browser

localhost/projects/symptoms/web/

Admin
admin@gmail.com
test

User
user@gmail.com
test
