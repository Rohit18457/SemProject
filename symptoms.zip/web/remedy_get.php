<?php
/*********************

**** CPanel ******************
*********/

/* Following code will match admin login credentials */

//user temp array
$response = array();

// include db connect class
require_once __DIR__ . '/db_connect.php';

// connecting to db



$data = json_decode(file_get_contents("php://input"));

$get_field_1 = ($data->field_1);
$get_type = ($data->field_9);

$result = mysqli_query($conn,"SELECT * FROM symptom  WHERE field_1 = '$get_field_1' AND field_9 = '$get_type'");

if(mysqli_num_rows($result))
{
	$response["details"] = array();	

	while($Alldetails = mysqli_fetch_array($result))
	{
		// temp user array
		$details = array();
		$details = $Alldetails;
		array_push($response["details"],$details);
	
	
	

}
}
else
{
	$response["success"] = 0;	
	echo json_encode($response);
}
	

?>