var app = angular.module("myapp", ['ngCookies']);
app.controller("myappCtrl", function($scope, $cookies, $cookieStore, $http) 
{
	
/****************************************************************************/
/************************** Get Admin Details ***********************************/
/****************************************************************************/	
	$scope.cook_user_email = $cookieStore.get("cook_user_email");
	$scope.cook_admin_email = $cookieStore.get("cook_admin_email");

	$scope.user_logout = function() 
	{
		if(confirm("Are You Sure?"))
		{
			$cookies.cook_user_email = "";
			$cookies.cook_admin_email = "";
			$cookies.field_1 = "" ;
	        $cookies.field_2 = "" ;
	        $cookies.field_3 = "" ;
	        $cookies.field_4 = "" ;
	        $cookies.field_5 = "" ;
	        $cookies.field_6 = "" ;
	        $cookies.field_7 = "" ;
	        $cookies.field_8 = "" ;
			window.location = "index.html";
			return;
		}
		else
		{
			return false;
		}
	}
	/****************************************************************************/
/************************** Get Admin Details ***********************************/
/****************************************************************************/	
	$scope.cook_user_email = $cookieStore.get("cook_user_email");
	$scope.cook_admin_email = $cookieStore.get("cook_admin_email");

	$scope.admin_logout = function() 
	{
		if(confirm("Are You Sure?"))
		{
			$cookies.cook_user_email = "";
			$cookies.cook_admin_email = "";
			
			window.location = "index.html";
			return;
		}
		else
		{
			return false;
		}
	}

/****************************************************************************/
/************************** Add Complaint *********************************/
/****************************************************************************/
	$scope.create_student = function() 
	{		
		$scope.field_10 ="Nil";
		$http.post('create_student.php', {
		'field_1':$scope.field_1,'field_2':$scope.field_2,'field_3':$scope.field_3,'field_4':$scope.field_4,
		'field_5':$scope.field_5,'field_6':$scope.field_6,'field_7':$scope.field_7,'field_8':$scope.field_8,
		'field_9':$scope.field_9,'field_10':$scope.field_10,'email':$scope.cook_admin_email
		})
			.success(function(data, status, headers, config) 
		{
		
			if(data.success == 1)
			{
				alert("Created Successfully");
				window.location = "home.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else
			{
				alert("Un Successfully");
			}
       });
    }
    
	
/****************************************************************************/
/************************** Student Update *********************************/
/****************************************************************************/
$scope.update_student = function(cus_id,field_1,field_2,field_3,
								 field_4,field_5,field_6,field_7,field_8,field_9) 
	{
		window.location = "update_solution.html";
		$cookieStore.put("cook_cus_id",cus_id);
		$cookieStore.put("cook_field_1",field_1);
		$cookieStore.put("cook_field_2",field_2);
		$cookieStore.put("cook_field_3",field_3);
		$cookieStore.put("cook_field_4",field_4);
		$cookieStore.put("cook_field_5",field_5);
		$cookieStore.put("cook_field_6",field_6);
		$cookieStore.put("cook_field_7",field_7);
		$cookieStore.put("cook_field_8",field_8);
		$cookieStore.put("cook_field_9",field_9);
		return;
	}	
	
	$scope.cook_cus_id = $cookieStore.get("cook_cus_id");
	$scope.cook_field_1 = $cookieStore.get("cook_field_1");
	$scope.cook_field_2 = $cookieStore.get("cook_field_2");
	$scope.cook_field_3 = $cookieStore.get("cook_field_3");
	$scope.cook_field_4 = $cookieStore.get("cook_field_4");
	$scope.cook_field_5 = $cookieStore.get("cook_field_5");
	$scope.cook_field_6 = $cookieStore.get("cook_field_6");
	$scope.cook_field_7 = $cookieStore.get("cook_field_7");
	$scope.cook_field_8 = $cookieStore.get("cook_field_8");
	$scope.cook_field_9 = $cookieStore.get("cook_field_9");

	$scope.save_student = function() 
	{		
		$http.post('save_student.php',{
		'id':$scope.cook_cus_id,'field_1':$scope.cook_field_1,'field_2':$scope.cook_field_2,
		'field_3':$scope.cook_field_3,'field_4':$scope.cook_field_4,'field_5':$scope.cook_field_5,'field_6':$scope.cook_field_6,'field_7':$scope.cook_field_7,'field_8':$scope.cook_field_8,
		'field_9':$scope.cook_field_9})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Submited successfully");
				window.location = "admin_view_medicine_details.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }


	/****************************************************************************/
/************************** Add user problem *********************************/
/****************************************************************************/
	$scope.post = function() 
	{		
		$http.post('create_user_problem.php', {
		'field_1':$scope.field_1,'field_2':$scope.field_2,'field_3':$scope.field_3,'field_4':$scope.field_4,
		'field_5':$scope.field_5,'field_6':$scope.field_6,'field_7':$scope.field_7,'field_8':$scope.field_8,'email':$scope.cook_user_email
		})
			.success(function(data, status, headers, config) 
		{
		
			if(data.success == 1)
			{
				alert("Created Successfully");
				window.location = "search_sym_allo.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else
			{
				alert("Un Successfully");
			}
       });
    }
    
	

/****************************************************************************/
/************************** admin Details *********************************/
/****************************************************************************/
	$http.post('admin_get.php')
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.admin_details = data.details;
		}
		else
		{
			$scope.admin_details = "No Data Found !!!";
		}
    });
/****************************************************************************/
/************************** Get Feedback *********************************/
/****************************************************************************/
	$http.post('feedback_get.php')
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.feedback_details = data.details;
		}
		else
		{
			$scope.feedback_details = "No Data Found !!!";
		}
    });
	
	
	/****************************************************************************/
/************************** view medicine admin Type*********************************/
/****************************************************************************/
$http.post('get_medicine.php')
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.admin_view_medicine_details = data.details;
		}
		else
		{
			$scope.admin_view_medicine_details = "No Data Found !!!";
		}
    });


	/****************************************************************************/
/************************** delete medicine admin Type*********************************/
/****************************************************************************/

$scope.medicine_delete = function(cus_id) 
	{		
        $http.post('medicine_delete.php', 
		{
		'cus_id': cus_id
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Medicine Deleted Successful");
				window.location = "admin_view_medicine_details.html";
				return;
			}
			else if(data.success == 0)
			{
				alert("Error While Deleting Medicine!!");
			}
			else
			{
				alert("No id found");
			}
        });
    }

	/****************************************************************************/
/************************** Get Symptom Type*********************************/
/****************************************************************************/

	$http.post('sym_get.php')
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.sym_details = data.details;
		}
		else
		{
			$scope.sym_details = "No Data Found !!!";
		}
    });
	
	
	
	/****************************************************************************/
/************************** Get tablets Type*********************************/
/****************************************************************************/

	$http.post('tablet_get.php')
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.tablet_details = data.details;
		}
		else
		{
			$scope.tablet_details = "No Data Found !!!";
		}
    });
	
	
/****************************************************************************/
/************************** Get disease Type*********************************/
/****************************************************************************/

	$http.post('dis_get.php')
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.disease_details = data.details;
		}
		else
		{
			$scope.disease_details = "No Data Found !!!";
		}
    });
	
	
	
	/****************************************************************************/
/************************** Get problem Type*********************************/
/****************************************************************************/

	$http.post('get_problem.php')
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.problem_details = data.details;
		}
		else
		{
			$scope.problem_details = "No Data Found !!!";
		}
    });
	
	/**************************admin get user details***********************************/
	$http.post('admin_get_user_details.php')
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.admin_get_user_details = data.details;
		}
		else
		{
			$scope.admin_get_user_details = "No Data Found !!!";
		}
    });
	/**********************admin get user health details****************************************/
	
	$scope.health = function(email)
	{
		$cookieStore.put("cook_email",email);
		window.location = "admin_get_user_health_details.html";
		return;
	}
	$scope.cook_email = $cookieStore.get("cook_email");
/*******************************category ads view details *******************************************/
   $scope.cook_email = $cookieStore.get("cook_email");
	$http.post('admin_get_user_health_details.php',{'email': $scope.cook_email})
	 .success(function(data,headers,status,config)
	 {
		 if(data.success == 1)
		 {
			 $scope.admin_get_user_health_details = data.details;
		 }
		 else
		 {
			 $scope.admin_get_user_health_details = "No Data!";
		 }
	 });
/****************************************************************************/
/************************** Get All details  *********************************/
/****************************************************************************/
	$http.post('student_get.php')
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.details = data.details;
		}
		else
		{
			$scope.details = "No Data Found !!!";
		}
    });
	
	
	
	
	$http.get('get_cultural.php')
	.success(function (response) 
	{
		$scope.cultural_details = response.details;
	});
	/****************************************************************************/
/************************** Get My payment Details*********************************/
/****************************************************************************/
	$http.post('pay_get.php',{'email':$scope.cook_user_email})
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.my_pay_details = data.details;
		}
		else
		{
			$scope.my_pay_details = "No Data Found !!!";
		}
    });
	/****************************************************************************/
/************************** Get My payment Details*********************************/
/****************************************************************************/
	$http.post('pay_get_all.php')
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.all_pay_details = data.details;
		}
		else
		{
			$scope.all_pay_details = "No Data Found !!!";
		}
    });
/****************************************************************************/
/************************** Add create_conference *********************************/
/****************************************************************************/
	$scope.create_cultural = function() 
	{		
		$http.post('create_sym_type.php', {
		'field_1':$scope.field_1,'email':$scope.cook_admin_email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Symptoms Added Successfully");
				window.location = "home.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else
				{
					alert("Un Successfully");
				}
        });
    }
	
	/****************************************************************************/
/************************** Add tablets by admin *********************************/
/****************************************************************************/
	$scope.post_tablet = function() 
	{		
		$http.post('post_tablet.php', {
		'field_1':$scope.field_1,'email':$scope.cook_admin_email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Tablet Added Successfully");
				window.location = "home.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else
				{
					alert("Un Successfully");
				}
        });
    }
	
/****************************************************************************/
/************************** Post problem by admin*********************************/
/****************************************************************************/
	$scope.post_problem = function() 
	{		
		$http.post('post_problem.php', {
		'field_1':$scope.field_1,'email':$scope.cook_admin_email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Problems Added Successfully");
				window.location = "home.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else
				{
					alert("Un Successfully");
				}
        });
    }
	
	/****************************************************************************/
/************************** Post disease by admin*********************************/
/****************************************************************************/
	$scope.post_disease = function() 
	{		
		$http.post('post_disease.php', {
		'field_1':$scope.field_1,'email':$scope.cook_admin_email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Disease Added Successfully");
				window.location = "home.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else
				{
					alert("Un Successfully");
				}
        });
    }


/****************************************************************************/
/************************** Add Requriments *********************************/
/****************************************************************************/
	$scope.create_feedback = function() 
	{		
		$http.post('create_feedback.php', 
		{
		'field_1':$scope.field_1,'field_2':$scope.field_2,'field_3':$scope.field_3,'field_4':$scope.field_4,
		'field_5':$scope.field_5,'field_6':$scope.field_6,'field_7':$scope.field_7,'field_8':$scope.field_8,'email':$scope.cook_admin_email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Symptoms Created Successfully");
				window.location = "home.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else if(data.success == 0)
			{
				alert("Error In Creating");
			}
			else
				{
					alert("Un Successfully");
				}
        });
    }
	/****************************************************************************/
/************************** Delete Allopathy *********************************/
/****************************************************************************/
	// products_delete
	$scope.sym_delete = function(cus_id) 
	{		
        $http.post('sym_delete.php', 
		{
		'cus_id': cus_id
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Product Deleted Successful");
				window.location = "view_symptom.html";
				return;
			}
			else if(data.success == 0)
			{
				alert("Error While Deleting Product!!");
			}
			else
			{
				alert("No id found");
			}
        });
    }

/****************************************************************************/
/**************************Allo Update *********************************/
/****************************************************************************/
$scope.update_sym = function(cus_id,field_1,field_2,field_3,field_4,field_5,field_6,field_7,field_8) 
	{
		window.location = "update_symptom.html";
		$cookieStore.put("cook_cus_id",cus_id);
		$cookieStore.put("cook_field_1",field_1);
		$cookieStore.put("cook_field_2",field_2);
		$cookieStore.put("cook_field_3",field_3);
		$cookieStore.put("cook_field_4",field_4);
		$cookieStore.put("cook_field_5",field_5);
		$cookieStore.put("cook_field_6",field_6);
		$cookieStore.put("cook_field_7",field_7);
		$cookieStore.put("cook_field_8",field_8);
		return;
	}	
	
	$scope.cook_cus_id = $cookieStore.get("cook_cus_id");
	$scope.cook_field_1 = $cookieStore.get("cook_field_1");
	$scope.cook_field_2 = $cookieStore.get("cook_field_2");
	$scope.cook_field_3 = $cookieStore.get("cook_field_3");
	$scope.cook_field_4 = $cookieStore.get("cook_field_4");
	$scope.cook_field_5 = $cookieStore.get("cook_field_5");
	$scope.cook_field_6 = $cookieStore.get("cook_field_6");
	$scope.cook_field_7 = $cookieStore.get("cook_field_7");
	$scope.cook_field_8 = $cookieStore.get("cook_field_8");
	
	$scope.save_sym = function() 
	{		
		$http.post('save_sym.php',{
		'id':$scope.cook_cus_id,'field_1':$scope.cook_field_1,'field_2':$scope.cook_field_2,
		'field_3':$scope.cook_field_3,'field_4':$scope.cook_field_4,'field_5':$scope.cook_field_5,'field_6':$scope.cook_field_6,'field_7':$scope.cook_field_7,'field_8':$scope.cook_field_8})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Submitted successfully");
				window.location = "view_symptom.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }

		/****************************************************************************/
/************************** Delete SMART HEALTHCARE *********************************/
/****************************************************************************/
	// products_delete
	$scope.sym_type_delete = function(cus_id) 
	{		
        $http.post('sym_type_delete.php', 
		{
		'cus_id': cus_id
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Product Deleted Successful");
				window.location = "view_sym_type.html";
				return;
			}
			else if(data.success == 0)
			{
				alert("Error While Deleting Product!!");
			}
			else
			{
				alert("No id found");
			}
        });
    }
	
		/****************************************************************************/
/************************** Delete diseases *********************************/
/****************************************************************************/
	// products_delete
	$scope.disease_delete = function(dis_id) 
	{		
        $http.post('disease_delete.php', 
		{
		'id': dis_id
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Diseases Deleted Successful");
				window.location = "view_disease.html";
				return;
			}
			else if(data.success == 0)
			{
				alert("Error While Deleting Diseases!!");
			}
			else
			{
				alert("No id found");
			}
        });
    }
	
		/****************************************************************************/
/************************** Delete tablets *********************************/
/****************************************************************************/
	// products_delete
	$scope.tablet_delete = function(tid) 
	{		
        $http.post('tablet_delete.php', 
		{
		'id': tid
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Tablet Deleted Successful");
				window.location = "view_tablet.html";
				return;
			}
			else if(data.success == 0)
			{
				alert("Error While Deleting Tablet!!");
			}
			else
			{
				alert("No id found");
			}
        });
    }
	
	
		/****************************************************************************/
/************************** Delete Problems *********************************/
/****************************************************************************/
	// products_delete
	$scope.problem_delete = function(pid) 
	{		
        $http.post('problem_delete.php', 
		{
		'id': pid
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Problems Deleted Successful");
				window.location = "view_problem.html";
				return;
			}
			else if(data.success == 0)
			{
				alert("Error While Deleting Problems!!");
			}
			else
			{
				alert("No id found");
			}
        });
    }

/****************************************************************************/
/************************** Symptom Type Update *********************************/
/****************************************************************************/
$scope.update_symtype = function(cus_id,field_1) 
	{
		window.location = "update_sym_type.html";
		$cookieStore.put("cook_cus_id",cus_id);
		$cookieStore.put("cook_symptom",field_1);
		
		
		
		return;
	}	
	
	$scope.cook_cus_id = $cookieStore.get("cook_cus_id");
	$scope.cook_symptom = $cookieStore.get("cook_symptom");
	
	
	$scope.save_sym_type = function() 
	{		
		$http.post('save_sym_type.php',{
		'id':$scope.cook_cus_id,'field_1':$scope.cook_symptom})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Submitted successfully");
				window.location = "view_sym_type.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }
	 
	 
 /****************************************************************************/
/************************** disease Type Update *********************************/
/****************************************************************************/
$scope.update_disease = function(dis_id,field_1) 
	{
		window.location = "update_disease.html";
		$cookieStore.put("cook_dis_id",dis_id);
		$cookieStore.put("cook_disease",field_1);
		
		
		
		return;
	}	
	
	$scope.cook_dis_id = $cookieStore.get("cook_dis_id");
	$scope.cook_disease = $cookieStore.get("cook_disease");
	
	
	$scope.save_disease = function() 
	{		
		$http.post('save_disease.php',{
		'id':$scope.cook_dis_id,'field_1':$scope.cook_disease})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Submitted successfully");
				window.location = "view_disease.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }
	 
	/****************************************************************************/
/************************** tablets Type Update *********************************/
/****************************************************************************/
$scope.update_tablet = function(tid,field_1) 
	{
		window.location = "update_tablet.html";
		$cookieStore.put("cook_tid",tid);
		$cookieStore.put("cook_tablet",field_1);
		
		
		
		return;
	}	
	
	$scope.cook_tid = $cookieStore.get("cook_tid");
	$scope.cook_tablet = $cookieStore.get("cook_tablet");
	
	
	$scope.save_tablet = function() 
	{		
		$http.post('save_tablet.php',{
		'id':$scope.cook_tid,'field_1':$scope.cook_tablet})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Submitted successfully");
				window.location = "view_tablet.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }
	 
	  
	 
	/****************************************************************************/
/************************** problem Type Update *********************************/
/****************************************************************************/
$scope.update_problem = function(pid,field_1) 
	{
		window.location = "update_problem.html";
		$cookieStore.put("cook_pid",pid);
		$cookieStore.put("cook_problem",field_1);
		
		
		
		return;
	}	
	
	$scope.cook_pid = $cookieStore.get("cook_pid");
	$scope.cook_problem = $cookieStore.get("cook_problem");
	
	
	$scope.save_problem = function() 
	{		
		$http.post('save_problem.php',{
		'id':$scope.cook_pid,'field_1':$scope.cook_problem})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Submitted successfully");
				window.location = "view_problem.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }
/****************************************************************************/
/************************** Remedies Update *********************************/
/****************************************************************************/
$scope.update_rem = function(cus_id,field_1,field_2,field_3,field_4,field_5,field_6) 
	{
		window.location = "update_remedy.html";
		$cookieStore.put("cook_cus_id",cus_id);
		$cookieStore.put("cook_field_1",field_1);
		$cookieStore.put("cook_field_2",field_2);
		$cookieStore.put("cook_field_3",field_3);
		$cookieStore.put("cook_field_4",field_4);
		$cookieStore.put("cook_field_5",field_5);
		$cookieStore.put("cook_field_6",field_6);
		
		return;
	}	
	
	$scope.cook_cus_id = $cookieStore.get("cook_cus_id");
	$scope.cook_field_1 = $cookieStore.get("cook_field_1");
	$scope.cook_field_2 = $cookieStore.get("cook_field_2");
	$scope.cook_field_3 = $cookieStore.get("cook_field_3");
	$scope.cook_field_4 = $cookieStore.get("cook_field_4");
	$scope.cook_field_5 = $cookieStore.get("cook_field_5");
	$scope.cook_field_6 = $cookieStore.get("cook_field_6");

	
	$scope.save_rem = function() 
	{		
		$http.post('save_rem.php',{
		'id':$scope.cook_cus_id,'field_1':$scope.cook_field_1,'field_2':$scope.cook_field_2,
		'field_3':$scope.cook_field_3,'field_4':$scope.cook_field_4,'field_5':$scope.cook_field_5,'field_6':$scope.cook_field_6})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Submitted successfully");
				window.location = "view_remedy.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }

		/****************************************************************************/
/************************** Delete Remedy *********************************/
/****************************************************************************/
	// products_delete
	$scope.remedy_delete = function(cus_id) 
	{		
        $http.post('remedy_delete.php', 
		{
		'cus_id': cus_id
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Product Deleted Successful");
				window.location = "view_remedy.html";
				return;
			}
			else if(data.success == 0)
			{
				alert("Error While Deleting Product!!");
			}
			else
			{
				alert("No id found");
			}
        });
    }

/****************************************************************************/
/************************** Cultural Update *********************************/
/****************************************************************************/
$scope.update_culture = function(cus_id,field_1,field_2,field_3) 
	{
		window.location = "update_cultural.html";
		$cookieStore.put("cook_cus_id",cus_id);
		$cookieStore.put("cook_field_1",field_1);
		$cookieStore.put("cook_field_2",field_2);
		$cookieStore.put("cook_field_3",field_3);
	
		return;
	}	
	
	$scope.cook_cus_id = $cookieStore.get("cook_cus_id");
	$scope.cook_field_1 = $cookieStore.get("cook_field_1");
	$scope.cook_field_2 = $cookieStore.get("cook_field_2");
	$scope.cook_field_3 = $cookieStore.get("cook_field_3");


	$scope.save_cultural = function() 
	{		
		$http.post('save_cultural.php',{
		'id':$scope.cook_cus_id,'field_1':$scope.cook_field_1,'field_2':$scope.cook_field_2,
		'field_3':$scope.cook_field_3})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Update successfully");
				window.location = "view_cultural.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }

	
	/****************************************************************************/
/************************** Delete Distribution Center *********************************/
/****************************************************************************/
	// products_delete
	$scope.distribute_delete = function(cus_id) 
	{		
        $http.post('distribute_delete.php', 
		{
		'cus_id': cus_id
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Product Deleted Successful");
				window.location = "view_cultural.html";
				return;
			}
			else if(data.success == 0)
			{
				alert("Error While Deleting Product!!");
			}
			else
			{
				alert("No id found");
			}
        });
    }
/****************************************************************************/
/************************** Search Doctor*********************************/
/****************************************************************************/
$scope.search_doctor = function(field_1,field_2) 
	{
		window.location = "user_view_doctor.html";
		$cookieStore.put("cook_field_1",field_1);
		$cookieStore.put("cook_field_2",field_2);
		return;
	}	
	$scope.cook_field_1 = $cookieStore.get("cook_field_1");
	$scope.cook_field_2 = $cookieStore.get("cook_field_2");
	
		$http.post('doctor_get.php',
		{
			'field_1':$scope.cook_field_1,'field_2':$scope.cook_field_2
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{			
				$scope.search_doc_info = data.details;
			}
			else
			{
				$scope.search_doc_info = "No Data Found !!!";
			}
          });
		  
	
/****************************************************************************/
/************************** Search Treatment *********************************/
/****************************************************************************/
$scope.search_treatment = function(field_2) 
	{
	
		$cookieStore.put("cook_treatment_type",field_2);
		if($scope.cook_treatment_type == "Doctor")
		
			{			
				window.location = "search_sym_allo.html";
				
				
			}
			else
			{
			window.location = "search_sym_remedy.html";
			}
		
		}
		
		
	$scope.cook_treatment_type = $cookieStore.get("cook_treatment_type");
	
	/****************************************************************************/
/************************** Search symptoms *********************************/
/****************************************************************************/

$scope.search_disease = function(field_1,field_2) 
	{
	
		$cookieStore.put("cook_field_1",field_1);
		$cookieStore.put("cook_field_2",field_2);
		window.location = "search_sym_allo.html";
		return;
	}	
	
	$scope.cook_field_1 = $cookieStore.get("cook_field_1");
	$scope.cook_field_2 = $cookieStore.get("cook_field_2");


/****************************************************************************/
/************************** user get new solution *********************************/
/****************************************************************************/	
		
		$http.post('user_get_problems.php',{
			'field_1': $scope.cook_field_1,'field_2': $scope.cook_field_2
		 })
		.success(function(data, status, headers, config) 
		{
				$scope.user_problem_details = data.details;
        });	
	
	
/****************************************************************************/
/************************** Search Treatment *********************************/
/****************************************************************************/
$scope.search_allo = function(field_1) 
	{
	
		$cookieStore.put("cook_allo",field_1);
		window.location = "user_view_allo.html";
	}	
	$scope.cook_allo = $cookieStore.get("cook_allo");
	$http.post('allo_get.php',
		{
			'field_1':$scope.cook_allo,'field_9':$scope.cook_treatment_type
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{			
					
					$scope.search_allo_info = data.details;
			}
			else
			{
			$scope.search_allo_info = "No Data Found !!!";
			
			}
          });

	
		/****************************************************************************/
/************************** Search Treatment *********************************/
/****************************************************************************/
$scope.search_home = function(field_1) 
	{
	
		$cookieStore.put("cook_field_1",field_1);
		window.location = "user_view_remedy.html";
	}	
	
	$scope.cook_field_1 = $cookieStore.get("cook_field_1");
	
	$http.post('remedy_get.php',
		{
			'field_1':$scope.cook_field_1,'field_9':$scope.cook_treatment_type
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{			
					
					$scope.search_rem_info = data.details;
				
				
			}
		
		
			else
			{
			$scope.search_rem_info = "No Data Found !!!";
			
			}
          });

	
		    /*****************************************************************************/
/**************************Remedy View More Info *********************************/
/****************************************************************************/

	$scope.more_rem = function(cus_id) 
	{		
		$cookieStore.put("cook_cus_id",cus_id);
		window.location = "full_view_remedy.html";
		return;				
    }
	
	$scope.cook_cus_id = $cookieStore.get("cook_cus_id");
	
	$http.post('more_info_rem.php',{'cus_id':$scope.cook_cus_id})
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.info_rem_details = data.details;
			
		}
		else
		{
			$scope.info_rem_details = "No Data Found !!!";
		}
		
    });
	
	
	/********************************************************************************************************/
	/*********************user_view_my_health details*********************************************************/
	/********************************************************************************************************/
	$scope.cook_user_email = $cookieStore.get("cook_user_email");
	$http.post('user_view_health_info.php',
		{
			'email':$scope.cook_user_email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{			
				$scope.user_view_health_info_details = data.details;
			}
          });
		  
		  
		  $scope.user_health_update = function(field_1,field_2,field_3,field_4,field_5) 
	{
		
		$cookieStore.put("field_1",field_1);
		$cookieStore.put("field_2",field_2);
		$cookieStore.put("field_3",field_3);
		$cookieStore.put("field_4",field_4);
		$cookieStore.put("field_5",field_5);
		window.location = "user_health_edit_info.html";
		return;
	}	
	
	$scope.field_1 = $cookieStore.get("field_1");
	$scope.field_2 = $cookieStore.get("field_2");
	$scope.field_3 = $cookieStore.get("field_3");
	$scope.field_4 = $cookieStore.get("field_4");
	$scope.field_5 = $cookieStore.get("field_5");

	$scope.save_health = function() 
	{		
		$http.post('user_health_edit_info.php',{
		 'field_1':$scope.field_1, 'field_2':$scope.field_2,
		 'field_3': $scope.field_3, 'field_4': $scope.field_4,'field_5': $scope.field_5,
		 'email':$scope.cook_user_email})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Submitted successfully");
				window.location = "user_view_health_info.html";
		
			$cookies.field_1 = "" ;
	        $cookies.field_2 = "" ;
	        $cookies.field_3 = "" ;
	        $cookies.field_4 = "" ;
	        $cookies.field_5 = "" ;

				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });	
			
     }


 /*****************************************************************************/
/**************************Remedy View More Info *********************************/
/****************************************************************************/

	$scope.more_allo = function(cus_id) 
	{		
		$cookieStore.put("cook_cus_id",cus_id);
		window.location = "full_view_allo.html";
		return;				
    }
	
	$scope.cook_cus_id = $cookieStore.get("cook_cus_id");
	
	$http.post('more_info.php',{'cus_id':$scope.cook_cus_id})
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.info_allo_details = data.details;
			
		}
		else
		{
			$scope.info_allo_details = "No Data Found !!!";
		}
    });
    /*****************************************************************************/
/**************************Doctor View More Info *********************************/
/****************************************************************************/

	$scope.more_doc = function(cus_id) 
	{		
		$cookieStore.put("cook_cus_id",cus_id);
		window.location = "full_view_doctor.html";
		return;				
    }
	
	$scope.cook_cus_id = $cookieStore.get("cook_cus_id");
	
	$http.post('more_info.php',{'cus_id':$scope.cook_cus_id})
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.info_doc_details = data.details;
			
		}
		else
		{
			$scope.info_doc_details = "No Data Found !!!";
		}
    });

	/****************************************************************************/
/**************************Create Appointment*********************************/
/****************************************************************************/
$scope.create_booking = function(cus_id,field_3,field_7) 
	{
		window.location = "create_pay.html";
		$cookieStore.put("cook_cus_id",cus_id);
	$cookieStore.put("cook_field_3",field_3);
		$cookieStore.put("cook_field_7",field_7);
		
		return;
	}	
	
	$scope.cook_cus_id = $cookieStore.get("cook_cus_id");
	$scope.cook_field_3 = $cookieStore.get("cook_field_3");
	$scope.cook_field_7 = $cookieStore.get("cook_field_7");
	
	
	$scope.create_pay = function() 
	{		
		$http.post('create_pay.php',{
		'id':$scope.cook_cus_id,'field_3':$scope.cook_field_3,'field_4':$scope.field_4,'field_5':$scope.field_5,'field_7':$scope.cook_field_7,'email':$scope.cook_user_email})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Paid successfully");
				window.location = "view_my_payment.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }

	/****************************************************************************/
/************************** Admin Update *********************************/
/****************************************************************************/
	
		$http.post('get_admin_info.php',
		{
			'email':$scope.cook_admin_email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{			
				$scope.admindetails = data.details;
			}
          });
		  
$scope.admin_update_info = function(name,password,mobile) 
	{
		window.location = "admin_info_edit.html";
		$cookieStore.put("cook_name",name);
		$cookieStore.put("cook_password",password);
		$cookieStore.put("cook_mobile",mobile);
		return;
	}	
	
	$scope.cook_name = $cookieStore.get("cook_name");
	$scope.cook_password = $cookieStore.get("cook_password");
	$scope.cook_mobile = $cookieStore.get("cook_mobile");

	$scope.save_update_admininfo = function() 
	{		
		$http.post('admin_update.php',{
		 'name':$scope.cook_name, 'password':$scope.cook_password,
		 'mobile': $scope.cook_mobile, 'email': $scope.cook_admin_email})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Submited successfully");
				window.location = "admin_update_info.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }

	
/****************************************************************************/
/************************** User Update *********************************/
/****************************************************************************/
	
		$http.post('get_user_info.php',
		{
			'email':$scope.cook_user_email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{			
				$scope.userdetails = data.details;
			}
          });
		  
$scope.user_update_info = function(name,password,mobile) 
	{
		window.location = "user_info_edit.html";
		$cookieStore.put("cook_name",name);
		$cookieStore.put("cook_password",password);
		$cookieStore.put("cook_mobile",mobile);
		return;
	}	
	
	$scope.cook_name = $cookieStore.get("cook_name");
	$scope.cook_password = $cookieStore.get("cook_password");
	$scope.cook_mobile = $cookieStore.get("cook_mobile");

	$scope.save_update_info = function() 
	{		
		$http.post('user_update_info.php',{
		 'name':$scope.cook_name, 'password':$scope.cook_password,
		 'mobile': $scope.cook_mobile, 'email': $scope.cook_user_email})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Submited successfully");
				window.location = "user_update_info.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }

		/****************************************************************************/
/************************** Add Feedback*********************************/
/****************************************************************************/
	$scope.add_feedback = function() 
	{		
		$http.post('create_feedback.php', {
		'field_1':$scope.field_1,'email':$scope.cook_user_email,'field_2':$scope.field_2
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Created Successfully");
				window.location = "user_home.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else
			{
				alert("Un Successfully");
			}
        });
    }

	
});